Die Webextension "Moodle Pro" Oder "Moodle-Premium" für die HTL Spengergasse erhebt keinerlei Daten.
Im Falle einer Änderung dieses Zustandes werden alle Nutzer darüber in Kentniss gesetzt bevor Sie die Extension nutzen.
