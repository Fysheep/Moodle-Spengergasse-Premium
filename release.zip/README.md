# MoodlePremium for HTL Spengergasse Extension 

## Future Updates and Features: 

### Current Version 1.3: 
  + Dark Theme

### Version 1.4: 
  + Fixed Darkmode for recent Moodle Update
