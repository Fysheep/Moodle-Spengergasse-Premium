# MoodlePremium for HTL Spengergasse Extension 

## Future Updates and Features: 

### Current Version 1.3: 
  + Dark Theme

### Version 1.4: 
  + Better Interface

### Version 1.5: 
  + Automated Features
  + More Unkown Features
